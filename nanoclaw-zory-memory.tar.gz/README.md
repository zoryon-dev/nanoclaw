# Zory no NanoClaw — Guia de Setup

## Como funciona a memória viva

O NanoClaw usa arquivos `CLAUDE.md` como memória persistente. O agente (Claude) lê esses arquivos automaticamente ao iniciar cada conversa E pode escrever neles durante a conversa. Isso cria uma "memória viva" que se atualiza sozinha.

### Hierarquia

```
groups/
├── CLAUDE.md                          ← Memória GLOBAL (lida por todos)
│                                        Identidade da Zory, Zoryon, stack, regras
│
├── whatsapp_main/                     ← Canal pessoal do Jonas
│   └── CLAUDE.md                        Admin, rotinas, notas pessoais
│
├── whatsapp_marcos-salomao/           ← Grupo do cliente
│   ├── CLAUDE.md                        Memória viva do cliente (auto-atualiza)
│   ├── brevo-setup.md                   Docs técnicos
│   ├── lancamento-oratoria.md           Contexto do lançamento atual
│   └── leads-analise.md                 Análises de dados
│
├── whatsapp_vk-digital/               ← Grupo do cliente
│   └── CLAUDE.md                        Memória viva do cliente
│
└── whatsapp_{novo-cliente}/           ← Novo cliente (usar template)
    └── CLAUDE.md                        Copiar de TEMPLATE_NOVO_CLIENTE.md
```

### O que cada nível faz

| Nível | Quem lê | Quem escreve | O que contém |
|-------|---------|-------------|-------------|
| Global (`groups/CLAUDE.md`) | Todos os grupos | Só o main | Identidade, empresa, stack, regras |
| Main (`whatsapp_main/CLAUDE.md`) | Só o main | Só o main | Admin, rotinas, lista de clientes |
| Cliente (`whatsapp_*/CLAUDE.md`) | Só aquele grupo | Aquele grupo | Tudo sobre o cliente — se atualiza |

### A mágica: auto-atualização

Cada `CLAUDE.md` de cliente tem uma instrução no topo:

> ⚠️ INSTRUÇÃO DE MEMÓRIA: Este arquivo é sua memória viva sobre este cliente.
> Sempre que uma informação relevante mudar, ATUALIZE este arquivo imediatamente.

Isso faz o agente escrever no próprio CLAUDE.md quando:
- Um lançamento novo começa
- Uma decisão técnica é tomada
- Uma pendência é resolvida (ou criada)
- Dados relevantes mudam

Na próxima conversa, o agente já lê a versão atualizada.

## Setup no NanoClaw

1. Copie a pasta `groups/` para dentro do seu fork do NanoClaw
2. Registre os grupos via main channel:
   - `@Zory add group "Marcos Salomão"` → folder: `whatsapp_marcos-salomao`
   - `@Zory add group "VK Digital"` → folder: `whatsapp_vk-digital`
3. Mude o trigger word para `@Zory` (editar `src/config.ts` ou usar env `ASSISTANT_NAME=Zory`)

## Adicionando novo cliente

1. Crie a pasta: `groups/whatsapp_{nome-do-cliente}/`
2. Copie `TEMPLATE_NOVO_CLIENTE.md` como `CLAUDE.md` dentro da pasta
3. Preencha os campos iniciais
4. Registre o grupo no NanoClaw: `@Zory add group "Nome do Cliente"`
5. A partir daí, a Zory mantém a memória sozinha

## Arquivos extras por cliente

Além do `CLAUDE.md`, cada pasta de cliente pode ter arquivos `.md` adicionais:

- **brevo-setup.md** — Documentação técnica do Brevo
- **lancamento-{nome}.md** — Contexto de lançamentos específicos
- **leads-analise.md** — Relatórios de análise de dados
- **historico-decisoes.md** — Decisões importantes documentadas
- **pendencias.md** — Lista detalhada de pendências (quando o CLAUDE.md fica grande demais)

O agente pode ler e escrever todos esses arquivos dentro da pasta do grupo.
