# Cliente: Marcos Salomão Educação

> ⚠️ INSTRUÇÃO DE MEMÓRIA: Este arquivo é sua memória viva sobre este cliente.
> Sempre que uma informação relevante mudar (novo lançamento, decisão técnica,
> problema resolvido, pendência nova), ATUALIZE este arquivo imediatamente.
> Use a tool de escrita para editar as seções relevantes.
> Mantenha conciso — fatos, não narrativas.

## Perfil

- Tipo: Infoprodutor de educação
- Plataforma de vendas: Hotmart (+30 produtos digitais)
- Ritmo: 2-3 lançamentos por mês
- Relação: Cliente ativo da Zoryon

## Status Atual

- **Lançamento ativo**: Oratória (LC_2025_03_ORATORIA)
- **Fase**: Captação de leads
- **Próximo produto**: mentoria_oratoria
- **Última atualização**: Março 2026

## Infraestrutura de Email (Brevo)

- Migração concluída: ActiveCampaign → Brevo
- Listas: por origem de captação (padrão LC_ANO_MES_NOME)
- Regra universal: toda chamada API usa `updateEnabled: true`

### Atributos configurados

| Atributo | Tipo | Uso |
|----------|------|-----|
| LANCAMENTOS | text (acumulado com vírgula) | Todos os lançamentos que o lead participou |
| TIPO_CONTATO | category (lead/aluno/ex_aluno/vip) | Classificação do contato |
| ORIGEM_PRINCIPAL | text | De onde o lead veio originalmente |
| RESPONDEU_PESQUISA | boolean | Se respondeu pesquisa de qualificação |
| PESQUISA_DADOS | text (JSON) | Respostas da pesquisa |
| RENDA_MENSAL | category (ate_3k/3k_6k/6.1k_10k/10.1k_15k/acima_15k) | Faixa de renda declarada |
| PROFISSAO | multiple-choice | Profissão declarada |

### Atributos transacionais (fase futura — quando abrir carrinho)

ORDER_ID, ORDER_PRODUTO, ORDER_STATUS, ORDER_VALOR, ORDER_DATA, ORDER_LANCAMENTO

### Track Events (via n8n → Brevo API)

- lead_captado
- pesquisa_respondida
- compra_aprovada, pix_gerado, reembolso (fase futura)

### Stack de integração

Hotmart/Forms → Webhooks → n8n → Brevo API

## Pendências Conhecidas

- [ ] BREVO_AUTOMATION_KEY precisa ser configurada como env var na Vercel
- [ ] Labels RENDA_MENSAL desatualizados (ate_3k OK, 3k_6k→3k_7k, 6.1k_10k→7k_15k, 10.1k_15k→15k_30k, acima_15k→acima_30k)
- [ ] Variantes de LP sem redirect para pesquisa geram leads sem dados de segmentação

## Dados Recorrentes

- Análise de vendas Hotmart
- Merge/dedup de listas de leads
- Normalização de telefones (formato +55XX9XXXXXXXX)
- Cross-reference leads x base de alunos

## Histórico de Decisões

- Listas no Brevo: poucas, só por origem (evita bug de contato duplicado)
- Atributos text com acumulação via GET→concatenar→PUT (vs multiple-choice)
- Track Events para gatilhos de automação (em vez de mudança de atributo)
- Opção B escolhida para PRODUTOS: texto com vírgula (100% API, sem intervenção manual)

## Documentação Disponível

- `brevo-setup.md` — Guia técnico completo (endpoints, payloads, Claude Code)
- `lancamento-oratoria.md` — Setup específico da fase de captação atual
