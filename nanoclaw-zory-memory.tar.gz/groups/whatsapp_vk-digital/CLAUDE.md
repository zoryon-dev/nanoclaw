# Cliente: VK Digital

> ⚠️ INSTRUÇÃO DE MEMÓRIA: Este arquivo é sua memória viva sobre este cliente.
> Sempre que uma informação relevante mudar, ATUALIZE este arquivo imediatamente.
> Mantenha conciso — fatos, não narrativas.

## Perfil

- Tipo: Renovação de contrato
- Serviços: Tráfego pago + automações + IA
- Contrato: Inclui estrutura de comissão de afiliado
- Relação: Cliente ativo da Zoryon

## Status Atual

- **Fase**: Renovação de contrato
- **Última atualização**: Março 2026

## Histórico de Decisões

<!-- Adicionar decisões conforme forem tomadas -->

## Pendências

<!-- Adicionar pendências conforme surgirem -->
