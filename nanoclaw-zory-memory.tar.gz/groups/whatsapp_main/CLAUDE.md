# Canal Principal — Jonas

> Este é o canal de controle pessoal de Jonas.
> Daqui ele gerencia todos os grupos, agenda tarefas, e conversa sobre
> assuntos que não são de nenhum cliente específico.

## Instruções de Memória

Quando Jonas pedir para "lembrar globalmente", atualize o `../CLAUDE.md` (memória global).
Quando for algo pessoal ou de admin, atualize este arquivo.

## Clientes Ativos

| Cliente | Grupo | Status |
|---------|-------|--------|
| Marcos Salomão Educação | whatsapp_marcos-salomao | Ativo — Lançamento Oratória |
| VK Digital | whatsapp_vk-digital | Ativo — Renovação contrato |

## Rotinas Configuradas

<!-- Adicionar rotinas do scheduler conforme criadas -->
<!-- Exemplo: Briefing matinal 08:00, Review semanal sexta 17:00 -->

## Produtividade

- Metodologia: Eat the Frog — tarefa mais difícil/importante primeiro
- Cockpit: Akiflow
- Regra: manter simples. Solo operator. Não empilhar ferramentas

## Tarefas Recorrentes do Admin

- Verificar emails prioritários (Gmail)
- Revisar agenda do dia (Calendar)
- Checar pendências nos clientes
- Atualizar memórias dos clientes quando houver mudanças

## Notas

<!-- Adicionar notas soltas, ideias, brainstorms que não pertencem a nenhum cliente -->
